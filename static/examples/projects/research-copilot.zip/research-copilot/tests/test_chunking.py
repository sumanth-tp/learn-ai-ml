from langchain_core.documents import Document

from research_copilot.ingestion import chunk_documents


def test_every_chunk_carries_citation_metadata():
    docs = [Document(page_content="word " * 600, metadata={"source": "a.txt"})]
    chunks = chunk_documents(docs, "txt", chunk_size=500, chunk_overlap=100)
    assert len(chunks) > 1
    for number, chunk in enumerate(chunks):
        assert chunk.metadata["kind"] == "txt"
        assert chunk.metadata["chunk_id"] == number
        assert chunk.metadata["citation"] == f"a.txt#{number}"
        assert len(chunk.page_content) <= 500


def test_missing_source_is_filled_in():
    chunks = chunk_documents([Document(page_content="hello world")], "txt")
    assert chunks[0].metadata["source"] == "unknown"


def test_chunks_overlap():
    text = " ".join(f"w{i}" for i in range(400))
    chunks = chunk_documents([Document(page_content=text, metadata={"source": "s"})], "txt", 300, 100)
    tail = set(chunks[0].page_content.split()[-5:])
    assert tail & set(chunks[1].page_content.split())
