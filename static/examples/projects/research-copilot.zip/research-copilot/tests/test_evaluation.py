from research_copilot.evaluation import LexicalJudge, context_precision, context_recall, evaluate, faithfulness, load_golden, summarise


def test_golden_set_has_30_questions_including_5_unanswerable(settings):
    golden = load_golden(settings.golden_path)
    assert len(golden) == 30
    assert sum(1 for g in golden if not g["answerable"]) == 5
    assert len({g["id"] for g in golden}) == 30


def test_faithfulness_separates_supported_from_invented():
    judge = LexicalJudge()
    context = ["The penalty is Rs 300 plus GST for that month."]
    assert faithfulness("The penalty is Rs 300 plus GST.", context, judge) == 1.0
    assert faithfulness("Customers receive a free holiday every year.", context, judge) == 0.0


def test_context_recall_and_precision():
    judge = LexicalJudge()
    contexts = ["Annual leave is 24 days.", "Cats sleep a lot.", "Notice period is 60 days."]
    assert context_recall("24 days of annual leave", contexts, judge) == 1.0
    assert context_precision("24 days of annual leave", contexts, judge) == 1.0
    assert context_precision("24 days of annual leave", ["Cats sleep a lot."], judge) == 0.0


def test_offline_evaluation_numbers_are_stable(copilot):
    report = evaluate(copilot, load_golden(copilot.settings.golden_path), LexicalJudge())
    summary = report["summary"]
    assert summary["questions"] == 30
    assert summary["correct_refusal_rate"] == 0.8
    assert summary["false_refusal_rate"] == 0.04
    assert summary["citation_rate"] == 1
    assert summary["source_hit_rate"] == 1


def test_the_stand_in_is_fooled_by_a_near_miss(copilot):
    report = evaluate(copilot, load_golden(copilot.settings.golden_path), LexicalJudge())
    fooled = [r["id"] for r in report["rows"] if not r["answerable"] and not r["refused"]]
    assert fooled == ["q28"]


def test_summarise_handles_an_empty_unanswerable_set():
    rows = [{"id": "a", "answerable": True, "refused": False, "cited": True, "source_hit": True, "faithfulness": 1.0, "answer_relevancy": 1.0, "context_precision": 1.0, "context_recall": 1.0}]
    assert summarise(rows)["correct_refusal_rate"] is None
