import json

from research_copilot.config import ROOT


def test_three_routes_end_to_end(copilot):
    document = copilot.ask("What penalty is charged when the monthly average balance is below the minimum?")
    assert document.route == "documents" and "300" in document.answer and document.citations
    live = copilot.ask("What is (120 * 3) / 4 ?")
    assert live.route == "live" and "90" in live.answer
    chat = copilot.ask("hello")
    assert chat.route == "chitchat" and not chat.citations


def test_every_question_is_logged_with_latency_and_tokens(copilot):
    copilot.ask("hello")
    copilot.ask("What is the notice period for resignation for permanent employees?")
    lines = [json.loads(line) for line in copilot.settings.log_path.read_text().splitlines()]
    assert [line["route"] for line in lines] == ["chitchat", "documents"]
    assert all(line["latency_ms"] >= 0 and "input_tokens" in line for line in lines)
    assert lines[0]["input_tokens"] > 0


def test_cost_uses_the_configured_prices(copilot):
    copilot.settings.price_in_per_million = 1000.0
    copilot.settings.price_out_per_million = 2000.0
    copilot.ask("hello")
    record = json.loads(copilot.settings.log_path.read_text().splitlines()[-1])
    assert record["cost_usd"] > 0


def test_ingesting_twice_does_not_duplicate_chunks(copilot):
    from research_copilot.index import all_chunks, ingest, library_sources

    before = len(all_chunks(copilot.store))
    ingest(library_sources(copilot.settings.data_dir), copilot.settings, copilot.store)
    assert len(all_chunks(copilot.store)) == before


def test_the_index_survives_a_restart(copilot, settings):
    from research_copilot.index import all_chunks, get_store

    assert len(all_chunks(get_store(settings))) == len(all_chunks(copilot.store)) > 10


def test_readme_documents_every_module():
    readme = (ROOT / "README.md").read_text()
    for path in (ROOT / "src" / "research_copilot").glob("*.py"):
        if path.stem not in {"__init__"}:
            assert path.name in readme, f"{path.name} is missing from the README structure"
