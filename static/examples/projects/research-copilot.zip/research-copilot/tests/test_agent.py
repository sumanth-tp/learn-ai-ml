from research_copilot.agent import build_agent, run_agent
from research_copilot.offline import ExtractiveChatModel
from research_copilot.tools import build_tools


def test_agent_uses_the_calculator(copilot):
    agent = build_agent(copilot.llm, build_tools(copilot.retriever))
    text, used = run_agent(agent, "What is (120 * 3) / 4 ?")
    assert text == "The result is 90."
    assert used == ["calculator"]


def test_agent_searches_the_library(copilot):
    agent = build_agent(copilot.llm, build_tools(copilot.retriever))
    text, used = run_agent(agent, "Search the library: how many days of sick leave?")
    assert used == ["search_library"]
    assert "sick leave" in text.lower()


def test_agent_step_limit_stops_a_runaway_loop(copilot):
    class Looping(ExtractiveChatModel):
        def _agent_step(self, messages):
            from langchain_core.messages import AIMessage

            return AIMessage(content="", tool_calls=[{"name": "calculator", "args": {"expression": "1+1"}, "id": "c1"}])

    agent = build_agent(Looping(), build_tools(copilot.retriever))
    text, used = run_agent(agent, "go", max_steps=2)
    assert text == "I could not finish within the step limit."
    assert used == []
