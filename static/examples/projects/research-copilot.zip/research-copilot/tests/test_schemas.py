from langchain_core.utils.function_calling import convert_to_openai_function

from research_copilot.schemas import Answer, GroundedAnswer, Route, Verdict


def strict_function(schema):
    return convert_to_openai_function(schema, strict=True)["parameters"]


def test_model_facing_schemas_are_strict_mode_friendly():
    for schema in (GroundedAnswer, Route, Verdict):
        parameters = strict_function(schema)
        assert parameters["additionalProperties"] is False
        assert set(parameters["required"]) == set(parameters["properties"])
        assert "default" not in str(parameters)


def test_the_model_never_chooses_the_route_or_web_use():
    assert set(GroundedAnswer.model_fields) == {"answer", "citations", "confidence"}
    assert {"route", "used_web"} <= set(Answer.model_fields)


def test_answer_extends_the_grounded_answer():
    assert issubclass(Answer, GroundedAnswer)
    result = Answer(answer="x", citations=[], confidence="low")
    assert result.route == "documents" and result.used_web is False
