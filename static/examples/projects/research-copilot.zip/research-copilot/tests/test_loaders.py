import pytest

from research_copilot.ingestion import loaders


def test_txt_and_csv(tmp_path):
    (tmp_path / "n.txt").write_text("hello", encoding="utf-8")
    (tmp_path / "t.csv").write_text("sku,price\nA1,10\nB2,20\n", encoding="utf-8")
    assert loaders.load_source("txt", str(tmp_path / "n.txt"))[0].page_content == "hello"
    rows = loaders.load_source("csv", str(tmp_path / "t.csv"))
    assert [r.metadata["row"] for r in rows] == [1, 2]
    assert rows[1].page_content == "sku: B2\nprice: 20"


def test_pdf_pages_become_documents(tmp_path):
    body = b"BT /F1 12 Tf 72 720 Td (Hello PDF world) Tj ET"
    objects = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>",
        b"<< /Length %d >>\nstream\n" % len(body) + body + b"\nendstream",
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
    ]
    pdf = b"%PDF-1.4\n"
    offsets = []
    for number, obj in enumerate(objects, start=1):
        offsets.append(len(pdf))
        pdf += b"%d 0 obj\n" % number + obj + b"\nendobj\n"
    xref = len(pdf)
    pdf += b"xref\n0 %d\n0000000000 65535 f \n" % (len(objects) + 1)
    pdf += b"".join(b"%010d 00000 n \n" % o for o in offsets)
    pdf += b"trailer\n<< /Size %d /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF" % (len(objects) + 1, xref)
    path = tmp_path / "h.pdf"
    path.write_bytes(pdf)
    docs = loaders.load_source("pdf", str(path))
    assert docs[0].metadata == {"source": "h.pdf", "page": 1}
    assert "Hello PDF world" in docs[0].page_content


def test_web_strips_scripts_and_navigation(monkeypatch):
    html = "<html><head><title>T</title><script>x=1</script></head><body><nav>menu</nav><p>Body text</p></body></html>"

    class Response:
        text = html

        def raise_for_status(self):
            return None

    monkeypatch.setattr(loaders.httpx, "get", lambda *a, **k: Response())
    doc = loaders.load_source("web", "https://example.com/page")[0]
    assert "Body text" in doc.page_content
    assert "menu" not in doc.page_content and "x=1" not in doc.page_content
    assert doc.metadata == {"source": "https://example.com/page", "title": "T"}


def test_youtube_uses_the_current_fetch_api(monkeypatch):
    class Snippet:
        def __init__(self, text):
            self.text = text

    class FakeApi:
        def fetch(self, video_id, languages=("en",)):
            assert video_id == "dQw4w9WgXcQ"
            return [Snippet("never gonna"), Snippet("give you up")]

    monkeypatch.setattr(loaders, "YouTubeTranscriptApi", FakeApi)
    docs = loaders.load_source("youtube", "https://www.youtube.com/watch?v=dQw4w9WgXcQ")
    assert docs[0].page_content == "never gonna give you up"
    assert docs[0].metadata["source"] == "youtube:dQw4w9WgXcQ"


def test_video_id_extraction():
    assert loaders.extract_video_id("https://youtu.be/dQw4w9WgXcQ") == "dQw4w9WgXcQ"
    assert loaders.extract_video_id("dQw4w9WgXcQ") == "dQw4w9WgXcQ"


def test_unknown_kind_is_rejected():
    with pytest.raises(ValueError, match="unknown source kind"):
        loaders.load_source("docx", "x")
