from langchain_core.documents import Document

from research_copilot.index import all_chunks
from research_copilot.retrieval import HybridRetriever, compress_context, reciprocal_rank_fusion


def doc(name):
    return Document(page_content=name, metadata={"citation": name})


def test_rrf_rewards_agreement_between_lists():
    fused = reciprocal_rank_fusion([[doc("a"), doc("b"), doc("c")], [doc("c"), doc("b")]])
    ranked = [d.metadata["citation"] for d in fused]
    assert set(ranked[:2]) == {"b", "c"}
    assert ranked[2] == "a"


def test_rrf_weights_change_the_winner():
    fused = reciprocal_rank_fusion([[doc("a")], [doc("b")]], weights=[0.1, 0.9])
    assert fused[0].metadata["citation"] == "b"


def test_keyword_search_finds_an_exact_product_code(copilot):
    top = copilot.retriever.keyword_search("NW-4410")[0]
    assert top.metadata["source"] == "product-catalogue.csv"
    assert "Summit Standing Desk" in top.page_content


def test_hybrid_returns_k_unique_chunks(copilot):
    docs = copilot.retriever.invoke("annual leave carry forward")
    assert len(docs) == copilot.settings.top_k
    assert len({d.metadata["citation"] for d in docs}) == len(docs)
    assert docs[0].metadata["source"] == "northwind-labs-handbook.md"


def test_empty_index_does_not_crash(settings):
    from research_copilot.index import get_store

    retriever = HybridRetriever(store=get_store(settings), chunks=[])
    assert retriever.keyword_search("anything") == []


def test_compression_keeps_the_relevant_sentences():
    long = Document(page_content="Cats sleep. The penalty is Rs 300. Dogs bark. Birds fly.", metadata={"citation": "x"})
    out = compress_context("what is the penalty", [long], keep_sentences=1)
    assert out[0].page_content == "The penalty is Rs 300."
    assert out[0].metadata["citation"] == "x"
