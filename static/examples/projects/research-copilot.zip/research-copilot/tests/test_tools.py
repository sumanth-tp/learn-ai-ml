import pytest

from research_copilot import tools
from research_copilot.tools import calculator, format_number, safe_eval


@pytest.mark.parametrize("expression,expected", [("(120 * 3) / 4", 90), ("2 ** 10", 1024), ("-5 + 8", 3), ("7 // 2", 3), ("10 % 4", 2)])
def test_safe_eval_arithmetic(expression, expected):
    assert safe_eval(expression) == expected


@pytest.mark.parametrize("expression", ["__import__('os').system('echo hi')", "open('/etc/passwd')", "2 ** 1000", "[1, 2]", "True + 1", "x + 1", "1; 2"])
def test_safe_eval_rejects_everything_else(expression):
    with pytest.raises((ValueError, SyntaxError)):
        safe_eval(expression)


def test_calculator_tool_returns_text_errors():
    assert calculator.invoke({"expression": "(120 * 3) / 4"}) == "90"
    assert calculator.invoke({"expression": "1 / 0"}).startswith("Error")
    assert calculator.invoke({"expression": "import os"}).startswith("Error")


def test_number_formatting():
    assert format_number(90.0) == "90"
    assert format_number(2.5) == "2.5"


def test_web_search_failure_is_returned_not_raised(monkeypatch):
    class Broken:
        def text(self, *a, **k):
            raise RuntimeError("offline")

    monkeypatch.setattr(tools, "DDGS", Broken)
    assert tools.web_search.invoke({"query": "x"}).startswith("Web search failed")


def test_web_search_marks_results_as_untrusted(monkeypatch):
    class Fake:
        def text(self, query, max_results=5):
            return [{"title": "T", "href": "https://e.com", "body": "B"}]

    monkeypatch.setattr(tools, "DDGS", Fake)
    assert tools.web_search.invoke({"query": "x"}).startswith("UNTRUSTED WEB RESULTS")


def test_every_tool_has_a_description_the_model_can_read(copilot):
    for t in tools.build_tools(copilot.retriever):
        assert len(t.description) > 30
