import pytest

from research_copilot.offline import keyword_route
from research_copilot.router import build_router, route_question


@pytest.mark.parametrize(
    "question,destination",
    [("hello", "chitchat"), ("Thanks!", "chitchat"), ("What is 12 * 7?", "live"), ("What is the weather today?", "live"), ("What is the notice period?", "documents")],
)
def test_keyword_route(question, destination):
    assert keyword_route(question).destination == destination


def test_router_chain_returns_a_destination(copilot):
    assert route_question(build_router(copilot.llm), "hi there") == "chitchat"


def test_router_failure_falls_back_to_documents():
    class Broken:
        def invoke(self, _):
            raise RuntimeError("provider down")

    assert route_question(Broken(), "anything") == "documents"
