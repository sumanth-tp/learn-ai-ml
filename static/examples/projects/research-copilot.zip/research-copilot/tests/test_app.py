import json

import pytest
from streamlit.testing.v1 import AppTest

from research_copilot.config import ROOT, get_settings


def button(at, label):
    return next(b for b in at.button if b.label == label)


def text_box(at, label):
    return next(t for t in at.text_input if t.label == label)


@pytest.fixture
def app(tmp_path, monkeypatch):
    monkeypatch.setenv("COPILOT_OFFLINE", "true")
    monkeypatch.setenv("COPILOT_DB_DIR", str(tmp_path / "db"))
    monkeypatch.setenv("COPILOT_LOG_PATH", str(tmp_path / "queries.jsonl"))
    get_settings.cache_clear()
    yield AppTest.from_file(str(ROOT / "app" / "streamlit_app.py"), default_timeout=30)
    get_settings.cache_clear()


def test_app_ingests_asks_and_records_feedback(app, tmp_path):
    at = app.run()
    assert not at.exception
    assert "Offline stand-in" in at.caption[0].value
    button(at, "Add the sample library").click().run()
    assert "Indexed" in at.sidebar.success[0].value
    text_box(at, "Ask a question").set_value("How many days of paid annual leave does a full-time employee receive?")
    button(at, "Ask").click().run()
    assert any("24 days" in m.value for m in at.markdown)
    assert any("Route: documents" in c.value for c in at.caption)
    button(at, "Helpful").click().run()
    feedback = json.loads((tmp_path / "feedback.jsonl").read_text().splitlines()[0])
    assert feedback["helpful"] is True
    assert feedback["question"].startswith("How many days")


def test_app_shows_an_error_for_a_bad_source(app):
    at = app.run()
    text_box(at, "Path, URL or video id").set_value("/no/such/file.txt")
    button(at, "Ingest").click().run()
    assert at.sidebar.error and "Could not ingest" in at.sidebar.error[0].value
