import pytest

from research_copilot.config import ROOT, Settings
from research_copilot.index import get_store, ingest, library_sources
from research_copilot.pipeline import Copilot


@pytest.fixture
def settings(tmp_path):
    return Settings(
        _env_file=None,
        offline=True,
        db_dir=tmp_path / "db",
        log_path=tmp_path / "queries.jsonl",
        data_dir=ROOT / "data" / "library",
        golden_path=ROOT / "eval" / "golden_set.jsonl",
    )


@pytest.fixture
def copilot(settings):
    store = get_store(settings)
    ingest(library_sources(settings.data_dir), settings, store)
    return Copilot(settings, store=store)
