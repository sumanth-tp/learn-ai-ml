# Northwind Labs Employee Handbook (excerpt)

## Annual leave
Every full-time employee receives 24 days of paid annual leave per calendar year. Up to 10 unused days can be carried forward into the next year. Carried-forward days expire on 31 March.

## Sick leave
Employees receive 12 days of paid sick leave per year. A medical certificate is required when sick leave lasts more than 3 consecutive days. Sick leave does not carry forward.

## Parental leave
The primary caregiver receives 26 weeks of paid parental leave. The secondary caregiver receives 4 weeks. Parental leave must start within 12 months of the birth or adoption.

## Remote work
Employees may work remotely up to 3 days per week. Teams agree the shared office days at the start of each quarter. Working from another country for more than 30 days a year needs written approval from the People team.

## Notice period
The notice period for resignation is 60 days for permanent employees and 30 days during the first 6 months of employment.

## Expenses
Meals during business travel are reimbursed up to Rs 1,500 per day. Receipts are required for any single expense above Rs 500. Claims must be submitted within 30 days of the expense.
