import json
import time

import streamlit as st

from research_copilot.config import get_settings
from research_copilot.index import library_sources
from research_copilot.index import ingest as ingest_sources
from research_copilot.ingestion import SOURCE_KINDS
from research_copilot.pipeline import Copilot

settings = get_settings()


@st.cache_resource
def get_copilot() -> Copilot:
    return Copilot(settings)


def save_feedback(question: str, answer: str, helpful: bool) -> None:
    path = settings.log_path.with_name("feedback.jsonl")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps({"ts": round(time.time(), 3), "question": question, "answer": answer, "helpful": helpful}) + "\n")


copilot = get_copilot()
st.title("Research Copilot")
st.caption("Offline stand-in model: not an LLM" if settings.offline else f"Model: {settings.chat_model}")

with st.sidebar:
    st.header("Library")
    if st.button("Add the sample library"):
        count = ingest_sources(library_sources(settings.data_dir), settings, copilot.store)
        copilot.refresh()
        st.success(f"Indexed {count} chunks")
    kind = st.selectbox("Source type", SOURCE_KINDS)
    reference = st.text_input("Path, URL or video id")
    if st.button("Ingest") and reference:
        try:
            count = ingest_sources([(kind, reference)], settings, copilot.store)
            copilot.refresh()
            st.success(f"Indexed {count} chunks")
        except Exception as exc:
            st.error(f"Could not ingest: {exc}")

question = st.text_input("Ask a question")
if st.button("Ask") and question:
    st.session_state["question"] = question
    st.session_state["result"] = copilot.ask(question)

result = st.session_state.get("result")
if result is not None:
    st.subheader("Answer")
    st.write(result.answer)
    st.caption(f"Route: {result.route} · Confidence: {result.confidence}" + (" · used web search" if result.used_web else ""))
    if result.citations:
        with st.expander("Citations"):
            for citation in result.citations:
                st.markdown(f"**{citation.source}**: {citation.quote}")
    helpful, not_helpful = st.columns(2)
    if helpful.button("Helpful"):
        save_feedback(st.session_state["question"], result.answer, True)
        st.toast("Saved")
    if not_helpful.button("Not helpful"):
        save_feedback(st.session_state["question"], result.answer, False)
        st.toast("Saved")
