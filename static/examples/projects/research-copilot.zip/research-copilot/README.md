# Research Copilot

A document-grounded research assistant built with LangChain 1.x. It ingests PDFs, web pages, CSVs, text and YouTube transcripts, answers questions **only from what it ingested**, cites the exact sentence it used, refuses when the documents do not support an answer, reaches for a calculator or the web when the library cannot help, and measures its own quality on a golden set.

It is the capstone of the GenAI course on this site. Every file maps to one milestone of the chapter.

## Run it in two minutes, with no API key

```bash
python -m venv .venv
.venv/bin/pip install -e ".[app,dev]"
export COPILOT_OFFLINE=true                 # uses a built-in stand-in model, not an LLM
.venv/bin/copilot ingest --library          # indexes data/library
.venv/bin/copilot ask "What is the minimum monthly average balance in a metro branch?"
.venv/bin/copilot eval                      # 30-question golden set
.venv/bin/python -m pytest -q               # offline tests
```

Offline mode is training wheels. `HashingEmbeddings` and `ExtractiveChatModel` in `src/research_copilot/offline.py` let the whole pipeline run and be tested without a network. The stand-in quotes the best-matching sentence; it is not a language model, and its evaluation numbers only prove that the wiring works.

## Run it with a real model

```bash
cp .env.example .env                        # then put your OPENAI_API_KEY in it
export COPILOT_OFFLINE=false
.venv/bin/copilot ingest --library
.venv/bin/copilot ask "How many days of paid parental leave does the primary caregiver receive?"
.venv/bin/streamlit run app/streamlit_app.py
```

`COPILOT_CHAT_MODEL` takes any `provider:model` string that `langchain.chat_models.init_chat_model` understands. Set it to a chat model you have access to. If you change `COPILOT_EMBEDDING_MODEL` you must delete `copilot_db/` and re-ingest, because chunks and queries must be embedded by the same model.

## Repository structure

```text
research-copilot/
├── README.md
├── pyproject.toml              dependencies, the `copilot` command, test settings
├── Makefile                    install, test, demo, ingest, eval, app
├── .env.example                the settings you can change
├── .gitignore
├── data/
│   └── library/                sample documents so it works on day one
│       ├── northwind-bank-savings.txt
│       ├── northwind-labs-handbook.md
│       ├── product-catalogue.csv
│       └── checkout-outage-postmortem.txt
├── eval/
│   ├── golden_set.jsonl        30 questions, 5 deliberately unanswerable
│   └── compare_retrievers.py   semantic vs keyword vs hybrid on the golden set
├── logs/                       queries.jsonl is written here (one line per question)
├── app/
│   └── streamlit_app.py        the interface
├── src/research_copilot/
│   ├── config.py               settings from environment variables
│   ├── models.py               get_llm(), get_embeddings()
│   ├── schemas.py              Citation, Answer, Route, Verdict
│   ├── ingestion/
│   │   ├── loaders.py          pdf, web, csv, txt, youtube -> Documents
│   │   └── chunking.py         splitting + the metadata that makes citations possible
│   ├── index.py                Chroma store: build, load, list all chunks
│   ├── retrieval.py            hybrid retriever (MMR + BM25, fused with RRF), compression
│   ├── prompts.py              every prompt in one place
│   ├── guardrails.py           quarantine chunks that look like prompt injection
│   ├── rag.py                  the grounded-answer chain and citation verification
│   ├── tools.py                search_library, web_search, calculator (safe parser)
│   ├── agent.py                create_agent + a step limit
│   ├── router.py               classify: documents, live or chitchat
│   ├── pipeline.py             Copilot.ask(): route, answer, log
│   ├── observability.py        JSONL logging, token and cost estimate
│   ├── evaluation.py           faithfulness, relevancy, precision, recall, refusals
│   ├── offline.py              stand-in embeddings and chat model
│   ├── text_utils.py           tokenising, stop words, sentence splitting
│   └── cli.py                  copilot ingest | ask | eval
└── tests/                      offline pytest suite
```

## Configuration

| Variable | Default | Meaning |
| --- | --- | --- |
| `COPILOT_CHAT_MODEL` | `openai:gpt-4o-mini` | `provider:model` for the chat model |
| `COPILOT_EMBEDDING_MODEL` | `text-embedding-3-small` | embedding model (fixed once you ingest) |
| `COPILOT_OFFLINE` | `false` | use the built-in stand-ins instead of a provider |
| `COPILOT_CHUNK_SIZE` / `COPILOT_CHUNK_OVERLAP` | `1000` / `200` | characters per chunk and the overlap between chunks |
| `COPILOT_TOP_K` / `COPILOT_FETCH_K` | `5` / `20` | chunks sent to the model / candidates fetched per retriever |
| `COPILOT_AGENT_MAX_STEPS` | `6` | cap on tool-calling steps |
| `COPILOT_PRICE_IN_PER_MILLION` / `..._OUT_...` | `0.0` | your provider's price per million tokens, for the cost estimate |

## Tested with

Python 3.12, `langchain` 1.4.3, `langchain-core` 1.6.6, `langchain-openai` 1.6.7, `langchain-chroma` 1.1.0, `langchain-text-splitters` 1.1.3, `langgraph` 1.2.12, `chromadb` 1.5.9, `youtube-transcript-api` 1.2.4, `ddgs` 9.16.0, `pydantic` 2.13.5, `rank-bm25` 0.2.2, `pypdf` 6.19.0, `streamlit` 1.65.0. Tested on 5 October 2026.
