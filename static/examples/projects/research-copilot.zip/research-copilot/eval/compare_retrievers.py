from statistics import mean

from research_copilot.config import get_settings
from research_copilot.evaluation import LexicalJudge, context_recall, load_golden
from research_copilot.index import all_chunks, get_store
from research_copilot.retrieval import HybridRetriever

settings = get_settings()
store = get_store(settings)
retriever = HybridRetriever(store=store, chunks=all_chunks(store), k=settings.top_k)
judge = LexicalJudge()
golden = [item for item in load_golden(settings.golden_path) if item["answerable"]]

methods = {
    "semantic only": lambda q: retriever.semantic_search(q)[: settings.top_k],
    "keyword only": lambda q: retriever.keyword_search(q)[: settings.top_k],
    "hybrid (RRF)": lambda q: retriever.invoke(q),
}
for name, search in methods.items():
    recalls, hits = [], []
    for item in golden:
        docs = search(item["question"])
        recalls.append(context_recall(item["ground_truth"], [d.page_content for d in docs], judge))
        hits.append(item["source"] in {d.metadata["source"] for d in docs})
    print(f"{name:14s} recall {mean(recalls):.2f}  source hit {mean(hits):.2f}")
