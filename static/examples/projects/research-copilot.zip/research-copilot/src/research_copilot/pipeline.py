import time

from langchain_core.callbacks import get_usage_metadata_callback
from langchain_core.language_models.chat_models import BaseChatModel

from research_copilot.agent import build_agent, run_agent
from research_copilot.config import Settings, get_settings
from research_copilot.index import all_chunks, get_store
from research_copilot.models import get_llm
from research_copilot.observability import estimate_cost, log_event
from research_copilot.prompts import CHITCHAT_SYSTEM
from research_copilot.rag import answer_from_documents
from research_copilot.retrieval import HybridRetriever
from research_copilot.router import build_router, route_question
from research_copilot.schemas import Answer
from research_copilot.tools import build_tools


class Copilot:
    def __init__(self, settings: Settings | None = None, llm: BaseChatModel | None = None, store=None) -> None:
        self.settings = settings or get_settings()
        self.llm = llm or get_llm(self.settings)
        self.store = store or get_store(self.settings)
        self.router = build_router(self.llm)
        self._retriever: HybridRetriever | None = None
        self._agent = None

    def refresh(self) -> None:
        self._retriever = None
        self._agent = None

    @property
    def retriever(self) -> HybridRetriever:
        if self._retriever is None:
            self._retriever = HybridRetriever(
                store=self.store,
                chunks=all_chunks(self.store),
                k=self.settings.top_k,
                fetch_k=self.settings.fetch_k,
            )
        return self._retriever

    @property
    def agent(self):
        if self._agent is None:
            self._agent = build_agent(self.llm, build_tools(self.retriever))
        return self._agent

    def ask(self, question: str) -> Answer:
        started = time.perf_counter()
        quarantined = 0
        with get_usage_metadata_callback() as usage:
            route = route_question(self.router, question)
            if route == "live":
                text, tools_used = run_agent(self.agent, question, self.settings.agent_max_steps)
                result = Answer(
                    answer=text,
                    citations=[],
                    confidence="medium" if tools_used else "low",
                    used_web="web_search" in tools_used,
                    route="live",
                )
            elif route == "chitchat":
                reply = self.llm.invoke([("system", CHITCHAT_SYSTEM), ("human", question)])
                result = Answer(answer=str(reply.content), citations=[], confidence="high", route="chitchat")
            else:
                result, _, quarantined = answer_from_documents(question, self.retriever, self.llm)
        tokens_in = sum(u.get("input_tokens", 0) for u in usage.usage_metadata.values())
        tokens_out = sum(u.get("output_tokens", 0) for u in usage.usage_metadata.values())
        log_event(
            {
                "question": question,
                "route": result.route,
                "confidence": result.confidence,
                "citations": [c.source for c in result.citations],
                "used_web": result.used_web,
                "quarantined_chunks": quarantined,
                "input_tokens": tokens_in,
                "output_tokens": tokens_out,
                "cost_usd": round(estimate_cost(tokens_in, tokens_out, self.settings), 6),
                "latency_ms": round((time.perf_counter() - started) * 1000, 1),
            },
            self.settings.log_path,
        )
        return result


_default: Copilot | None = None


def answer(question: str) -> Answer:
    global _default
    if _default is None:
        _default = Copilot()
    return _default.ask(question)
