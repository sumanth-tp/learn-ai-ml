from langchain_core.documents import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter


def chunk_documents(docs: list[Document], kind: str, chunk_size: int = 1000, chunk_overlap: int = 200) -> list[Document]:
    splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
    chunks = splitter.split_documents(docs)
    for number, chunk in enumerate(chunks):
        chunk.metadata.setdefault("source", "unknown")
        chunk.metadata["kind"] = kind
        chunk.metadata["chunk_id"] = number
        chunk.metadata["citation"] = f"{chunk.metadata['source']}#{number}"
    return chunks
