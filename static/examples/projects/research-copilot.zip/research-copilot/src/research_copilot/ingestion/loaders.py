import csv
import io
import re
from pathlib import Path

import httpx
from bs4 import BeautifulSoup
from langchain_core.documents import Document
from pypdf import PdfReader
from youtube_transcript_api import YouTubeTranscriptApi

SOURCE_KINDS = ("pdf", "web", "csv", "txt", "youtube")
USER_AGENT = "research-copilot/1.0 (+learning project)"


def load_pdf(path: str) -> list[Document]:
    reader = PdfReader(path)
    name = Path(path).name
    pages = []
    for number, page in enumerate(reader.pages, start=1):
        text = (page.extract_text() or "").strip()
        if text:
            pages.append(Document(page_content=text, metadata={"source": name, "page": number}))
    return pages


def load_web(url: str) -> list[Document]:
    response = httpx.get(url, headers={"User-Agent": USER_AGENT}, follow_redirects=True, timeout=20)
    response.raise_for_status()
    soup = BeautifulSoup(response.text, "html.parser")
    for tag in soup(["script", "style", "nav", "footer", "header", "aside"]):
        tag.decompose()
    text = re.sub(r"\n{3,}", "\n\n", soup.get_text("\n")).strip()
    title = soup.title.string.strip() if soup.title and soup.title.string else url
    return [Document(page_content=text, metadata={"source": url, "title": title})]


def load_csv(path: str) -> list[Document]:
    name = Path(path).name
    with open(path, newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    return [
        Document(
            page_content="\n".join(f"{column}: {value}" for column, value in row.items()),
            metadata={"source": name, "row": number},
        )
        for number, row in enumerate(rows, start=1)
    ]


def load_txt(path: str) -> list[Document]:
    return [Document(page_content=Path(path).read_text(encoding="utf-8"), metadata={"source": Path(path).name})]


def extract_video_id(reference: str) -> str:
    match = re.search(r"(?:v=|youtu\.be/|embed/)([A-Za-z0-9_-]{11})", reference)
    return match.group(1) if match else reference


def load_youtube(reference: str) -> list[Document]:
    video_id = extract_video_id(reference)
    transcript = YouTubeTranscriptApi().fetch(video_id, languages=["en"])
    text = " ".join(snippet.text for snippet in transcript)
    return [Document(page_content=text, metadata={"source": f"youtube:{video_id}"})]


LOADERS = {"pdf": load_pdf, "web": load_web, "csv": load_csv, "txt": load_txt, "youtube": load_youtube}


def load_source(kind: str, reference: str) -> list[Document]:
    if kind not in LOADERS:
        raise ValueError(f"unknown source kind {kind!r}; expected one of {SOURCE_KINDS}")
    return LOADERS[kind](reference)
