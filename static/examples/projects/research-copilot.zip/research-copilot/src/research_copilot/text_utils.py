import re

WORD = re.compile(r"[a-z0-9]+")
STOP = frozenset(
    "a an the of to in on for and or is are was were be by with at as it its this that what which who how "
    "when where why do does did can i you we they from about into your our their".split()
)


def tokenize(text: str) -> list[str]:
    return WORD.findall(text.lower())


def stem(word: str) -> str:
    for suffix in ("ing", "es", "s"):
        if len(word) > len(suffix) + 3 and word.endswith(suffix):
            return word[: -len(suffix)]
    return word


def content_words(text: str) -> list[str]:
    return [stem(word) for word in tokenize(text) if word not in STOP]


def split_sentences(text: str) -> list[str]:
    return [s.strip() for s in re.split(r"(?<=[.!?])\s+|\n+", text) if len(s.strip()) > 3]


def normalise(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip().lower()
