from langchain.chat_models import init_chat_model
from langchain_core.embeddings import Embeddings
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_openai import OpenAIEmbeddings

from research_copilot.config import Settings, get_settings
from research_copilot.offline import ExtractiveChatModel, HashingEmbeddings


def get_llm(settings: Settings | None = None, temperature: float = 0.1) -> BaseChatModel:
    settings = settings or get_settings()
    if settings.offline:
        return ExtractiveChatModel()
    return init_chat_model(settings.chat_model, temperature=temperature)


def get_embeddings(settings: Settings | None = None) -> Embeddings:
    settings = settings or get_settings()
    if settings.offline:
        return HashingEmbeddings()
    return OpenAIEmbeddings(model=settings.embedding_model)
