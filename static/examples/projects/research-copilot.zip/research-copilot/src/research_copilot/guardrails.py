import re

from langchain_core.documents import Document

INJECTION_PATTERNS = [
    re.compile(pattern, re.I)
    for pattern in (
        r"ignore (all |any |the )?(previous|prior|above|earlier)?\s*instructions",
        r"disregard (all |any |the )?(previous|prior|above|earlier)",
        r"you are now\b",
        r"reveal (the |your )?(system prompt|api key|secret|password)",
        r"</?context>",
    )
]


def scan_for_injection(text: str) -> list[str]:
    return [pattern.pattern for pattern in INJECTION_PATTERNS if pattern.search(text)]


def quarantine(docs: list[Document]) -> tuple[list[Document], list[Document]]:
    safe, flagged = [], []
    for doc in docs:
        (flagged if scan_for_injection(doc.page_content) else safe).append(doc)
    return safe, flagged
