import argparse
import json
import sys

from research_copilot.config import get_settings
from research_copilot.evaluation import LexicalJudge, LLMJudge, evaluate, format_report, load_golden, save_report
from research_copilot.index import get_store, ingest, library_sources
from research_copilot.ingestion import SOURCE_KINDS
from research_copilot.pipeline import Copilot


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="copilot", description="Research Copilot")
    commands = parser.add_subparsers(dest="command", required=True)

    ingest_cmd = commands.add_parser("ingest", help="Add documents to the index")
    ingest_cmd.add_argument("--library", action="store_true", help="Ingest every file in data/library")
    ingest_cmd.add_argument("--kind", choices=SOURCE_KINDS)
    ingest_cmd.add_argument("--ref", help="Path, URL or video id")

    ask_cmd = commands.add_parser("ask", help="Ask one question")
    ask_cmd.add_argument("question")

    eval_cmd = commands.add_parser("eval", help="Run the golden-set evaluation")
    eval_cmd.add_argument("--out", default="eval/report.json")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    settings = get_settings()
    if args.command == "ingest":
        sources = library_sources(settings.data_dir) if args.library else [(args.kind, args.ref)]
        if not args.library and not (args.kind and args.ref):
            print("give --library, or both --kind and --ref", file=sys.stderr)
            return 2
        print(f"ingested {ingest(sources, settings, get_store(settings))} chunks")
        return 0
    copilot = Copilot(settings)
    if args.command == "ask":
        print(json.dumps(copilot.ask(args.question).model_dump(), indent=2, ensure_ascii=False))
        return 0
    judge = LexicalJudge() if settings.offline else LLMJudge(copilot.llm)
    report = evaluate(copilot, load_golden(settings.golden_path), judge)
    save_report(report, args.out)
    print(format_report(report))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
