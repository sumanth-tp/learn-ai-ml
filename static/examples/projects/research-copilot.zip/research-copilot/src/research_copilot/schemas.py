from typing import Literal

from pydantic import BaseModel, Field

INSUFFICIENT = "INSUFFICIENT_CONTEXT"


class Citation(BaseModel):
    source: str = Field(description="Identifier of the cited chunk, copied from its [source#chunk] marker")
    quote: str = Field(description="The exact sentence from that chunk that supports the claim")


class GroundedAnswer(BaseModel):
    answer: str = Field(description=f"The answer, or {INSUFFICIENT} when the context does not support one")
    citations: list[Citation] = Field(description="One entry per supporting sentence; empty when the answer is a refusal")
    confidence: Literal["high", "medium", "low"] = Field(description="How strongly the context supports the answer")


class Answer(GroundedAnswer):
    used_web: bool = False
    route: Literal["documents", "live", "chitchat"] = "documents"


class Route(BaseModel):
    destination: Literal["documents", "live", "chitchat"] = Field(
        description=(
            "documents = answerable from the ingested library; "
            "live = needs current information or a calculation; "
            "chitchat = greeting or small talk"
        )
    )


class Verdict(BaseModel):
    supported: bool = Field(description="True when the context supports the claim")
