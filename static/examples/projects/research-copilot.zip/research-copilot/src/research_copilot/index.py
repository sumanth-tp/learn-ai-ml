from pathlib import Path

from langchain_chroma import Chroma
from langchain_core.documents import Document
from langchain_core.embeddings import Embeddings

from research_copilot.config import Settings, get_settings
from research_copilot.ingestion import chunk_documents, load_source
from research_copilot.models import get_embeddings

SUFFIX_TO_KIND = {".txt": "txt", ".md": "txt", ".csv": "csv", ".pdf": "pdf"}


def get_store(settings: Settings | None = None, embeddings: Embeddings | None = None) -> Chroma:
    settings = settings or get_settings()
    return Chroma(
        collection_name=settings.collection,
        embedding_function=embeddings or get_embeddings(settings),
        persist_directory=str(settings.db_dir),
    )


def library_sources(data_dir: Path) -> list[tuple[str, str]]:
    found = []
    for path in sorted(Path(data_dir).glob("*")):
        kind = SUFFIX_TO_KIND.get(path.suffix.lower())
        if kind:
            found.append((kind, str(path)))
    return found


def ingest(sources: list[tuple[str, str]], settings: Settings | None = None, store: Chroma | None = None) -> int:
    settings = settings or get_settings()
    store = store or get_store(settings)
    total = 0
    for kind, reference in sources:
        chunks = chunk_documents(load_source(kind, reference), kind, settings.chunk_size, settings.chunk_overlap)
        if chunks:
            store.add_documents(chunks, ids=[chunk.metadata["citation"] for chunk in chunks])
            total += len(chunks)
    return total


def all_chunks(store: Chroma) -> list[Document]:
    stored = store.get(include=["documents", "metadatas"])
    return [Document(page_content=text, metadata=meta) for text, meta in zip(stored["documents"], stored["metadatas"])]
