from langchain.agents import create_agent
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import ToolMessage
from langchain_core.tools import BaseTool
from langgraph.errors import GraphRecursionError

from research_copilot.prompts import AGENT_SYSTEM


def build_agent(llm: BaseChatModel, tools: list[BaseTool]):
    return create_agent(llm, tools, system_prompt=AGENT_SYSTEM)


def run_agent(agent, question: str, max_steps: int = 6) -> tuple[str, list[str]]:
    try:
        result = agent.invoke(
            {"messages": [{"role": "user", "content": question}]},
            config={"recursion_limit": max_steps * 2 + 1},
        )
    except GraphRecursionError:
        return "I could not finish within the step limit.", []
    messages = result["messages"]
    tools_used = [message.name for message in messages if isinstance(message, ToolMessage)]
    return str(messages[-1].content), tools_used
