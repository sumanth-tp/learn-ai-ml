from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import Runnable

from research_copilot.prompts import ROUTER_SYSTEM
from research_copilot.schemas import Route


def build_router(llm: BaseChatModel) -> Runnable:
    prompt = ChatPromptTemplate.from_messages([("system", ROUTER_SYSTEM), ("human", "{question}")])
    return prompt | llm.with_structured_output(Route)


def route_question(router: Runnable, question: str) -> str:
    try:
        return router.invoke({"question": question}).destination
    except Exception:
        return "documents"
