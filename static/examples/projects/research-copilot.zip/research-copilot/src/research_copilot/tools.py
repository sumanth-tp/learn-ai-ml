import ast
import operator

from ddgs import DDGS
from langchain_core.retrievers import BaseRetriever
from langchain_core.tools import BaseTool, tool

from research_copilot.prompts import format_docs

OPERATORS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv,
    ast.Mod: operator.mod,
    ast.Pow: operator.pow,
    ast.USub: operator.neg,
    ast.UAdd: operator.pos,
}
MAX_EXPONENT = 100


def safe_eval(expression: str) -> float:
    def evaluate(node: ast.AST) -> float:
        if isinstance(node, ast.Expression):
            return evaluate(node.body)
        if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)) and not isinstance(node.value, bool):
            return node.value
        if isinstance(node, ast.BinOp) and type(node.op) in OPERATORS:
            left, right = evaluate(node.left), evaluate(node.right)
            if isinstance(node.op, ast.Pow) and abs(right) > MAX_EXPONENT:
                raise ValueError("exponent too large")
            return OPERATORS[type(node.op)](left, right)
        if isinstance(node, ast.UnaryOp) and type(node.op) in OPERATORS:
            return OPERATORS[type(node.op)](evaluate(node.operand))
        raise ValueError("unsupported expression")

    return evaluate(ast.parse(expression.strip(), mode="eval"))


def format_number(value: float) -> str:
    return str(int(value)) if float(value).is_integer() else f"{value:.6g}"


@tool
def calculator(expression: str) -> str:
    """Evaluate an arithmetic expression such as '(120 * 3) / 4'. Supports + - * / // % ** and parentheses."""
    try:
        return format_number(safe_eval(expression))
    except (ValueError, SyntaxError, ZeroDivisionError, OverflowError) as exc:
        return f"Error: {exc}"


@tool
def web_search(query: str) -> str:
    """Search the public web for current information. Use only when the document library cannot answer."""
    try:
        results = DDGS().text(query, max_results=5)
    except Exception as exc:
        return f"Web search failed: {exc}"
    if not results:
        return "No results."
    lines = [f"{item.get('title', '')} ({item.get('href', '')})\n{item.get('body', '')}" for item in results]
    return "UNTRUSTED WEB RESULTS\n\n" + "\n\n".join(lines)


def make_search_library(retriever: BaseRetriever) -> BaseTool:
    @tool
    def search_library(query: str) -> str:
        """Search the ingested document library and return the most relevant passages with [source#chunk] markers."""
        return format_docs(retriever.invoke(query)) or "No matching passages."

    return search_library


def build_tools(retriever: BaseRetriever) -> list[BaseTool]:
    return [make_search_library(retriever), web_search, calculator]
