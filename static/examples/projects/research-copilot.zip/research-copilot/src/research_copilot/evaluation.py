import json
from pathlib import Path
from statistics import mean
from typing import Protocol

from langchain_core.documents import Document
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.prompts import ChatPromptTemplate

from research_copilot.pipeline import Copilot
from research_copilot.prompts import CLAIM_JUDGE_HUMAN, CLAIM_JUDGE_SYSTEM
from research_copilot.rag import answer_from_documents
from research_copilot.schemas import INSUFFICIENT, Verdict
from research_copilot.text_utils import content_words, split_sentences


class Judge(Protocol):
    def supported(self, claim: str, context: str) -> bool: ...

    def addresses(self, question: str, answer: str) -> bool: ...


class LexicalJudge:
    def __init__(self, threshold: float = 0.6) -> None:
        self.threshold = threshold

    def _overlap(self, source: str, target: str) -> float:
        wanted = set(content_words(source))
        return len(wanted & set(content_words(target))) / len(wanted) if wanted else 0.0

    def supported(self, claim: str, context: str) -> bool:
        return self._overlap(claim, context) >= self.threshold

    def addresses(self, question: str, answer: str) -> bool:
        return self._overlap(question, answer) >= 0.4


class LLMJudge:
    def __init__(self, llm: BaseChatModel) -> None:
        prompt = ChatPromptTemplate.from_messages([("system", CLAIM_JUDGE_SYSTEM), ("human", CLAIM_JUDGE_HUMAN)])
        self.chain = prompt | llm.with_structured_output(Verdict)

    def supported(self, claim: str, context: str) -> bool:
        return self.chain.invoke({"claim": claim, "context": context}).supported

    def addresses(self, question: str, answer: str) -> bool:
        return self.supported(f"The text answers the question: {question}", answer)


def faithfulness(answer: str, contexts: list[str], judge: Judge) -> float:
    claims = split_sentences(answer)
    joined = "\n".join(contexts)
    return mean(judge.supported(claim, joined) for claim in claims) if claims else 0.0


def context_recall(ground_truth: str, contexts: list[str], judge: Judge) -> float:
    claims = split_sentences(ground_truth) or [ground_truth]
    joined = "\n".join(contexts)
    return mean(judge.supported(claim, joined) for claim in claims)


def context_precision(ground_truth: str, contexts: list[str], judge: Judge) -> float:
    hits, precisions = 0, []
    for position, context in enumerate(contexts, start=1):
        if judge.supported(ground_truth, context):
            hits += 1
            precisions.append(hits / position)
    return mean(precisions) if precisions else 0.0


def load_golden(path: Path) -> list[dict]:
    return [json.loads(line) for line in Path(path).read_text(encoding="utf-8").splitlines() if line.strip()]


def evaluate(copilot: Copilot, golden: list[dict], judge: Judge) -> dict:
    rows = []
    for item in golden:
        result, docs, _ = answer_from_documents(item["question"], copilot.retriever, copilot.llm)
        contexts = [doc.page_content for doc in docs]
        refused = result.answer.strip() == INSUFFICIENT
        row = {
            "id": item["id"],
            "answerable": item["answerable"],
            "refused": refused,
            "answer": result.answer,
            "cited": bool(result.citations),
            "source_hit": item.get("source") in {doc.metadata["source"] for doc in docs} if item.get("source") else None,
        }
        if item["answerable"] and not refused:
            row["faithfulness"] = faithfulness(result.answer, contexts, judge)
            row["answer_relevancy"] = float(judge.addresses(item["question"], result.answer))
        if item["answerable"]:
            row["context_precision"] = context_precision(item["ground_truth"], contexts, judge)
            row["context_recall"] = context_recall(item["ground_truth"], contexts, judge)
        rows.append(row)
    return {"rows": rows, "summary": summarise(rows)}


def summarise(rows: list[dict]) -> dict:
    def average(key: str, subset: list[dict]) -> float | None:
        values = [row[key] for row in subset if key in row and row[key] is not None]
        return round(mean(values), 3) if values else None

    answerable = [row for row in rows if row["answerable"]]
    unanswerable = [row for row in rows if not row["answerable"]]
    answered = [row for row in answerable if not row["refused"]]
    return {
        "questions": len(rows),
        "answerable": len(answerable),
        "unanswerable": len(unanswerable),
        "correct_refusal_rate": round(mean(row["refused"] for row in unanswerable), 3) if unanswerable else None,
        "false_refusal_rate": round(mean(row["refused"] for row in answerable), 3) if answerable else None,
        "citation_rate": round(mean(row["cited"] for row in answered), 3) if answered else None,
        "source_hit_rate": average("source_hit", answerable),
        "faithfulness": average("faithfulness", answered),
        "answer_relevancy": average("answer_relevancy", answered),
        "context_precision": average("context_precision", answerable),
        "context_recall": average("context_recall", answerable),
    }


def format_report(report: dict) -> str:
    return "\n".join(f"{name:22s} {value}" for name, value in report["summary"].items())


def save_report(report: dict, path: Path) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
