from functools import lru_cache
from pathlib import Path

from dotenv import load_dotenv
from pydantic_settings import BaseSettings, SettingsConfigDict

ROOT = Path(__file__).resolve().parents[2]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="COPILOT_", env_file=".env", extra="ignore")

    chat_model: str = "openai:gpt-4o-mini"
    embedding_model: str = "text-embedding-3-small"
    offline: bool = False

    data_dir: Path = ROOT / "data" / "library"
    db_dir: Path = ROOT / "copilot_db"
    collection: str = "library"
    log_path: Path = ROOT / "logs" / "queries.jsonl"
    golden_path: Path = ROOT / "eval" / "golden_set.jsonl"

    chunk_size: int = 1000
    chunk_overlap: int = 200
    top_k: int = 5
    fetch_k: int = 20
    agent_max_steps: int = 6

    price_in_per_million: float = 0.0
    price_out_per_million: float = 0.0


@lru_cache
def get_settings() -> Settings:
    load_dotenv()
    return Settings()
