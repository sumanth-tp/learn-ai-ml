from typing import Any

from langchain_core.callbacks import CallbackManagerForRetrieverRun
from langchain_core.documents import Document
from langchain_core.retrievers import BaseRetriever
from pydantic import PrivateAttr
from rank_bm25 import BM25Okapi

from research_copilot.text_utils import content_words, split_sentences, tokenize


def reciprocal_rank_fusion(rankings: list[list[Document]], weights: list[float] | None = None, k: int = 60) -> list[Document]:
    weights = weights or [1.0] * len(rankings)
    scores: dict[str, float] = {}
    docs: dict[str, Document] = {}
    for ranking, weight in zip(rankings, weights):
        for position, doc in enumerate(ranking, start=1):
            key = doc.metadata["citation"]
            docs[key] = doc
            scores[key] = scores.get(key, 0.0) + weight / (k + position)
    return [docs[key] for key in sorted(scores, key=scores.get, reverse=True)]


class HybridRetriever(BaseRetriever):
    store: Any
    chunks: list[Document]
    k: int = 5
    fetch_k: int = 20
    weights: tuple[float, float] = (0.6, 0.4)
    _bm25: Any = PrivateAttr(default=None)

    def model_post_init(self, __context: Any) -> None:
        if self.chunks:
            self._bm25 = BM25Okapi([tokenize(chunk.page_content) for chunk in self.chunks])

    def keyword_search(self, query: str) -> list[Document]:
        if self._bm25 is None:
            return []
        scores = self._bm25.get_scores(tokenize(query))
        ranked = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)[: self.fetch_k]
        return [self.chunks[i] for i in ranked if scores[i] > 0]

    def semantic_search(self, query: str) -> list[Document]:
        return self.store.max_marginal_relevance_search(query, k=self.fetch_k, fetch_k=self.fetch_k * 2, lambda_mult=0.5)

    def _get_relevant_documents(self, query: str, *, run_manager: CallbackManagerForRetrieverRun) -> list[Document]:
        fused = reciprocal_rank_fusion([self.semantic_search(query), self.keyword_search(query)], list(self.weights))
        return fused[: self.k]


def compress_context(query: str, docs: list[Document], keep_sentences: int = 3) -> list[Document]:
    wanted = set(content_words(query))
    compressed = []
    for doc in docs:
        sentences = split_sentences(doc.page_content)
        scored = sorted(range(len(sentences)), key=lambda i: len(wanted & set(content_words(sentences[i]))), reverse=True)
        keep = sorted(scored[:keep_sentences])
        text = " ".join(sentences[i] for i in keep) if keep else doc.page_content
        compressed.append(Document(page_content=text, metadata=dict(doc.metadata)))
    return compressed
