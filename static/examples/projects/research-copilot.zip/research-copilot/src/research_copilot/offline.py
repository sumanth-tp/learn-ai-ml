import hashlib
import math
import re
from typing import Any

from langchain_core.embeddings import Embeddings
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, ToolMessage
from langchain_core.outputs import ChatGeneration, ChatResult
from langchain_core.runnables import RunnableLambda

from research_copilot.schemas import INSUFFICIENT, Citation, GroundedAnswer, Route, Verdict
from research_copilot.text_utils import content_words, split_sentences

CHUNK = re.compile(r"\[([^\]]+#\d+)\]\n(.*?)(?=\n\n\[[^\]]+#\d+\]\n|\Z)", re.S)
ARITHMETIC = re.compile(r"[\d(][\d\s.+\-*/()%]*[+\-*/][\d\s.+\-*/()%]*\d\)?")
LIVE_WORDS = ("today", "latest", "news", "weather", "current", "currently", "stock", "exchange rate", "right now", "search the web", "online")
GREETING = re.compile(r"^\s*(hi|hello|hey|thanks|thank you|good (morning|afternoon|evening)|how are you)\b", re.I)
ANSWER_THRESHOLD = 0.5


class HashingEmbeddings(Embeddings):
    def __init__(self, dimensions: int = 512) -> None:
        self.dimensions = dimensions

    def _embed(self, text: str) -> list[float]:
        vector = [0.0] * self.dimensions
        for word in content_words(text):
            digest = int(hashlib.md5(word.encode()).hexdigest(), 16)
            sign = 1.0 if (digest >> 64) & 1 else -1.0
            vector[digest % self.dimensions] += sign
        norm = math.sqrt(sum(v * v for v in vector)) or 1.0
        return [v / norm for v in vector]

    def embed_documents(self, texts: list[str]) -> list[list[float]]:
        return [self._embed(t) for t in texts]

    def embed_query(self, text: str) -> list[float]:
        return self._embed(text)


def _text_of(prompt: Any) -> tuple[str, list[BaseMessage]]:
    messages = prompt.to_messages() if hasattr(prompt, "to_messages") else list(prompt)
    return "\n".join(str(m.content) for m in messages), messages


def extractive_answer(text: str) -> GroundedAnswer:
    context_match = re.search(r"<context>\n(.*?)\n</context>", text, re.S)
    question_match = re.search(r"Question:\s*(.*)\Z", text, re.S)
    context = context_match.group(1) if context_match else ""
    question = question_match.group(1).strip() if question_match else ""
    wanted = set(content_words(question))
    best_score, best_source, best_sentence = 0.0, "", ""
    for source, body in CHUNK.findall(context):
        for sentence in split_sentences(body):
            score = len(wanted & set(content_words(sentence))) / len(wanted) if wanted else 0.0
            if score > best_score:
                best_score, best_source, best_sentence = score, source, sentence
    if best_score < ANSWER_THRESHOLD:
        return GroundedAnswer(answer=INSUFFICIENT, citations=[], confidence="low")
    return GroundedAnswer(
        answer=best_sentence,
        citations=[Citation(source=best_source, quote=best_sentence)],
        confidence="high" if best_score >= 0.8 else "medium",
    )


def keyword_route(question: str) -> Route:
    lowered = question.lower()
    if GREETING.match(question):
        return Route(destination="chitchat")
    if ARITHMETIC.search(question) or any(word in lowered for word in LIVE_WORDS):
        return Route(destination="live")
    return Route(destination="documents")


def lexical_verdict(text: str) -> Verdict:
    claim = re.search(r"Claim:\s*(.*?)\nContext:", text, re.S)
    context = re.search(r"Context:\s*(.*)\Z", text, re.S)
    claim_words = set(content_words(claim.group(1))) if claim else set()
    context_words = set(content_words(context.group(1))) if context else set()
    if not claim_words:
        return Verdict(supported=False)
    return Verdict(supported=len(claim_words & context_words) / len(claim_words) >= 0.6)


class ExtractiveChatModel(BaseChatModel):
    """Deterministic stand-in for a chat model. Not an LLM: it quotes, matches keywords and calls tools by rule."""

    tool_names: list[str] = []

    @property
    def _llm_type(self) -> str:
        return "extractive-offline"

    def bind_tools(self, tools: Any, **kwargs: Any) -> "ExtractiveChatModel":
        names = [t["name"] if isinstance(t, dict) else getattr(t, "name", str(t)) for t in tools]
        return self.model_copy(update={"tool_names": names})

    def with_structured_output(self, schema: Any, **kwargs: Any) -> RunnableLambda:
        handlers = {"GroundedAnswer": extractive_answer, "Verdict": lexical_verdict}

        def run(prompt: Any) -> Any:
            text, messages = _text_of(prompt)
            name = getattr(schema, "__name__", "")
            if name == "Route":
                human = [m for m in messages if isinstance(m, HumanMessage)]
                return keyword_route(str(human[-1].content) if human else text)
            if name in handlers:
                return handlers[name](text)
            raise NotImplementedError(f"offline model cannot produce {name}")

        return RunnableLambda(run)

    def _generate(self, messages: list[BaseMessage], stop: list[str] | None = None, run_manager: Any = None, **kwargs: Any) -> ChatResult:
        if self.tool_names:
            reply = self._agent_step(messages)
        else:
            human = [m for m in messages if isinstance(m, HumanMessage)]
            question = str(human[-1].content) if human else ""
            reply = AIMessage(content="Hello! Ask me about the documents in your library." if GREETING.match(question) else "I can only answer from the ingested library.")
        tokens_in = sum(len(str(m.content).split()) for m in messages)
        tokens_out = len(str(reply.content).split())
        reply.response_metadata = {"model_name": "extractive-offline"}
        reply.usage_metadata = {"input_tokens": tokens_in, "output_tokens": tokens_out, "total_tokens": tokens_in + tokens_out}
        return ChatResult(generations=[ChatGeneration(message=reply)])

    def _agent_step(self, messages: list[BaseMessage]) -> AIMessage:
        if isinstance(messages[-1], ToolMessage):
            output = str(messages[-1].content)
            if messages[-1].name == "calculator":
                return AIMessage(content=f"The result is {output}.")
            return AIMessage(content=output[:600])
        human = [m for m in messages if isinstance(m, HumanMessage)]
        question = str(human[-1].content) if human else ""
        arithmetic = ARITHMETIC.search(question)
        if arithmetic and "calculator" in self.tool_names:
            call = {"name": "calculator", "args": {"expression": arithmetic.group(0).strip()}}
        elif any(word in question.lower() for word in LIVE_WORDS) and "web_search" in self.tool_names:
            call = {"name": "web_search", "args": {"query": question}}
        else:
            call = {"name": "search_library", "args": {"query": question}}
        call["id"] = "call_" + hashlib.md5(question.encode()).hexdigest()[:8]
        return AIMessage(content="", tool_calls=[call])
