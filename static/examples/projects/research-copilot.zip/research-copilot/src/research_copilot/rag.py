from langchain_core.documents import Document
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.retrievers import BaseRetriever
from langchain_core.runnables import Runnable, RunnableLambda, RunnableParallel, RunnablePassthrough

from research_copilot.guardrails import quarantine
from research_copilot.prompts import ANSWER_HUMAN, ANSWER_SYSTEM, format_docs
from research_copilot.schemas import INSUFFICIENT, Answer, GroundedAnswer
from research_copilot.text_utils import normalise

ANSWER_PROMPT = ChatPromptTemplate.from_messages([("system", ANSWER_SYSTEM), ("human", ANSWER_HUMAN)])


def build_answer_chain(retriever: BaseRetriever, llm: BaseChatModel) -> Runnable:
    return (
        RunnableParallel(docs=retriever, question=RunnablePassthrough())
        | RunnablePassthrough.assign(context=RunnableLambda(lambda step: format_docs(step["docs"])))
        | RunnablePassthrough.assign(result=ANSWER_PROMPT | llm.with_structured_output(GroundedAnswer))
    )


def verify_citations(answer: GroundedAnswer, docs: list[Document]) -> GroundedAnswer:
    if answer.answer.strip() == INSUFFICIENT:
        return answer.model_copy(update={"citations": [], "confidence": "low"})
    text_by_id = {doc.metadata["citation"]: normalise(doc.page_content) for doc in docs}
    valid = [c for c in answer.citations if c.source in text_by_id and normalise(c.quote) in text_by_id[c.source]]
    if not valid:
        return GroundedAnswer(answer=INSUFFICIENT, citations=[], confidence="low")
    return answer.model_copy(update={"citations": valid})


def answer_from_documents(question: str, retriever: BaseRetriever, llm: BaseChatModel) -> tuple[Answer, list[Document], int]:
    retrieved = retriever.invoke(question)
    safe, flagged = quarantine(retrieved)
    drafted = (ANSWER_PROMPT | llm.with_structured_output(GroundedAnswer)).invoke({"context": format_docs(safe), "question": question})
    verified = verify_citations(drafted, safe)
    return Answer(**verified.model_dump(), route="documents"), safe, len(flagged)
