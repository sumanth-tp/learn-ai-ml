import json
import time
from pathlib import Path

from research_copilot.config import Settings


def estimate_cost(input_tokens: int, output_tokens: int, settings: Settings) -> float:
    return (input_tokens * settings.price_in_per_million + output_tokens * settings.price_out_per_million) / 1_000_000


def log_event(record: dict, path: Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps({"ts": round(time.time(), 3), **record}, ensure_ascii=False) + "\n")
